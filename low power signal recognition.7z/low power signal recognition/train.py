#-– coding:utf8 ––

import os
import time
import socket
import random
import logging
import argparse
import torch
import torch.distributed as dist
import torch.backends.cudnn as cudnn
from torch.multiprocessing import Process
import torch.multiprocessing as mp
from random import randint
from network.CNN import CNN as mymodel
from modules.trainer_uni_last_512FFT_256Shift_last_base import Executor


hostname = socket.gethostname()
logging.basicConfig(level=logging.INFO, filename = hostname + '_train.log', filemode = 'a', format='%(asctime)s  - %(message)s')
logging.basicConfig(level=logging.INFO, filename = hostname + '_train.log', filemode = 'a', format='%(asctime)s  - %(message)s')
logger = logging.getLogger(__name__)

parser = argparse.ArgumentParser(description='Deep Network for 901')
parser.add_argument('--train-path', default=['',''])
parser.add_argument('--train-key', default=['','']) 
parser.add_argument('--dev-path', default=[''])
parser.add_argument('--dev-key', default=[''])

parser.add_argument('--gpus', default=1, type=int)
parser.add_argument('--total-sample', default='49916', type=int)
parser.add_argument('--lr-rate', default=None, type=float)  #leaning rate
parser.add_argument('--nepochs', default=None, type=int)

parser.add_argument('--chunk-num', default=100, type=int)
parser.add_argument('--batch-size', default=None, type=int)
parser.add_argument('--model-dir', default='./models/') 
parser.add_argument('--check-point', default=None)
parser.add_argument('--display-freq', default=10, type=int)
parser.add_argument('--lrDecayEpochStart', default=10, type=int)
parser.add_argument('--lrDecayRatio', default=0.5, type=float)
parser.add_argument('--iswarmup', default=0, type=int)
parser.add_argument('--warmup_batch', default=800, type=float)
parser.add_argument('--cvtest-freq', default=800, type=int)
## bmuf
parser.add_argument('--alpha', default=0.75, type=float)
parser.add_argument('--bm', default=0.75, type=float)
parser.add_argument('--blr', default=1.0, type=float)
parser.add_argument('--sync-freq', default=20, type=float)
parser.add_argument("--local_rank", default=1, type=int)
parser.add_argument("--rank", default=0, type=int)
parser.add_argument("--partnum", default=1, type=int)
parser.add_argument("--quant", default=0, type=int)
args = parser.parse_args()

def run(args):
    cudnn.deterministic = True
    cudnn.benchmark = False
    cudnn.enabled = True
    torch.manual_seed(1234)
    torch.cuda.manual_seed(1234)
    torch.cuda.manual_seed_all(1234)  # if you are using multi-GPU.  

    executor = Executor(args)
    train_module = mymodel()
    train_module2 = mymodel()
    executor.fit(train_module, train_module2, delay=0)
    

def main(local_rank):
    """ Initialize the distributed environment. """
    if "MASTER_ADDR" in os.environ:
        master_addr = socket.gethostbyname(os.environ["MASTER_ADDR"])
        master_port = int(os.environ["MASTER_PORT"])
        args.world_size = int(os.environ["WORLD_SIZE"])
        args.rank = int(os.environ["RANK"])
    else:  
        master_addr = socket.gethostbyname("localhost")
        os.environ["MASTER_ADDR"] = master_addr
        os.environ["MASTER_PORT"] = '1234567'
        args.world_size = 1  
        args.rank = 0

    args.distributed_world_size = args.world_size * args.gpus     
    args.gpu_rank = args.rank * args.gpus + local_rank 
    # print(args.distributed_world_size, args.rank, local_rank)
    if args.distributed_world_size  // args.gpus > 1: 
        dist.init_process_group("nccl", init_method="tcp://{0}:{1}".format(master_addr, master_port), world_size=args.distributed_world_size, rank=args.gpu_rank)
    else:
        dist.init_process_group("gloo", init_method='env://', world_size=args.distributed_world_size, rank=args.gpu_rank)
    args.local_rank = local_rank
    torch.cuda.set_device(args.local_rank)
    args.rank = args.gpu_rank
    # print(args.gpu_rank, args.distributed_world_size)


    # 根据卡数选择bmuf参数
    if args.distributed_world_size > 1:
        if args.distributed_world_size == 4:
            args.alpha = 0.75
            args.bm = 0.75
            args.blr = 1.0
        elif args.distributed_world_size == 8:
            args.alpha = 1.0
            args.bm = 0.9
            args.blr = 1.0
        elif args.distributed_world_size == 12:
            args.alpha = 1.0
            args.bm = 0.92
            args.blr = 1.0
        elif args.distributed_world_size == 16:
            args.alpha = 1.0
            args.bm = 0.94
            args.blr = 1.0
        elif args.distributed_world_size == 20:
            args.alpha = 1.0
            args.bm = 0.954
            args.blr = 1.0
        elif args.distributed_world_size == 24:
            args.alpha = 1.0
            args.bm = 0.965
            args.blr = 1.0
        elif args.distributed_world_size == 28:
            args.alpha = 1.0
            args.bm = 0.97
            args.blr = 1.0
        elif args.distributed_world_size == 32:
            args.alpha = 1.0
            args.bm = 0.972
            args.blr = 1.0
        else:
            raise Exception("args.distributed_world_size {}, bmuf train failed".format(args.distributed_world_size))

    if args.rank == 0:
        for name in vars(args):
            value = getattr(args, name)
            logger.info('%s = %s' % (name, value))

    run(args)
    

    
if __name__ == "__main__":

    # if args.gpu_num < torch.cuda.device_count() or args.gpu_num > torch.cuda.device_count():
    #     args.gpu_num = torch.cuda.device_count()
    args.istrain = True
    print('gpus={}'.format(args.gpus))
    # mp.spawn(main, nprocs=args.gpus)
    
    gpu_device_id = 0
    args.world_size = 1
    args.rank = 1
    args.distributed_world_size = 1
    args.gpu_rank = gpu_device_id
    args.local_rank = gpu_device_id
    torch.cuda.set_device(gpu_device_id)

    run(args)
