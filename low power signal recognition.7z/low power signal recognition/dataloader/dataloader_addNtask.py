# -*- coding: utf-8 -*-

from __future__ import print_function
import torch
from torch import Tensor
import lmdb
import numpy as np
from torch.utils.data.dataset import Dataset
from torch.utils.data.dataloader import DataLoader
from torch.utils.data.distributed import DistributedSampler
from torch.utils.data.sampler import RandomSampler
from random import Random
from collections import OrderedDict
from modules.dataloader.datum1_pb2 import Datum1 as Datum
from modules.dataloader.my_utils import *
# import time
try:
    from prefetch_generator import BackgroundGenerator

    class PrefetchDataLoader(DataLoader):
        '''
            replace DataLoader with PrefetchDataLoader
        '''
        def __iter__(self):
            return BackgroundGenerator(super().__iter__())
except:
    print('prefetch_generator is not installed, use Torch DataLoader instead!!!')
    PrefetchDataLoader = DataLoader

class SpeechDataset(Dataset):
    def __init__(self, lmdb_path: str, lmdb_key: str, world_size: int, world_id: int, bunchsize: int=26214, seed=None, Tmax=None) -> None:
        self.lmdb_path_mic = lmdb_path
        self.bunchsize = bunchsize
        self.dic = OrderedDict()
        self.seed = seed if seed is not None else 1234
        with open(lmdb_key) as f:
            for line in f:
                v, k,_ = line.strip().split()
                if (Tmax is not None) and (int(k) > Tmax):
                    continue
                if int(k) not in self.dic.keys():
                    self.dic[int(k)]=[v] 
                else:             
                    self.dic[int(k)].append(v)
        
        self.batch_samples = []
        self.get_batch_samples()
        self.current_batch_samples = self.batch_samples #[world_id:-1:world_size]
        self._sizes = len(self.current_batch_samples)
        self.dataset_len = len(self.batch_samples)
        self.lmdb_env_mic = None #lmdb.Environment(lmdb_path, readonly=True, readahead=True, lock=False)

      
    def get_batch_samples(self) -> None:
        rng = Random() 
        rng.seed(self.seed)
        for k in self.dic:
            rng.shuffle(self.dic[k])
            n_samples = self.bunchsize // k

            tmp = []
            for sample in self.dic[k]:
                tmp.append(sample)
                if len(tmp) == n_samples:
                    self.batch_samples.append(tmp)
                    tmp = []
                                          
            if tmp:   #最后一个batch
                self.batch_samples.append(tmp) 

        rng.shuffle(self.batch_samples)
        del self.dic

    def __getitem__(self, index: int) -> Tensor:
        keys = self.current_batch_samples[index]
        txn_mic = self.lmdb_env_mic.begin()  # type: ignore

        batch = []
        pos_flag = [] # 存放主目标index
        with txn_mic.cursor() as cursor_mic:
            for k in keys:
                cursor_mic.set_key(k.encode())
                fea_proto_mic = Datum()
                fea_proto_mic.ParseFromString(cursor_mic.value()) # type: ignore
                #data_mic = np.frombuffer(fea_proto_mic.anc.data, dtype=np.int16).reshape(-1,160).reshape(1,-1) # mic1 mic2 noise_for_target clean_for_target gevd gevd_noise_for_target gevd_clean_for_target
                data_mic = np.frombuffer(fea_proto_mic.anc.data, dtype=np.int16).reshape(3,-1)             
                data_mic = torch.from_numpy(data_mic.copy()).float().unsqueeze(0)
                batch.append(data_mic)

        return torch.cat(batch)

    def __len__(self) -> int:
        return self._sizes

def worker_init_fn(worker_id):
    worker_info = torch.utils.data.get_worker_info()
    dataset = worker_info.dataset

    # 初始化lmdb
    dataset.lmdb_env_mic = lmdb.Environment(dataset.lmdb_path_mic, readonly=True, readahead=True, lock=False)


def load_data(lmdb_file, keyfile, batch_size, num_part, part_index, bunchsize=26214, shuffle_seed=None, num_workers=4, epoch=None, Tmax=None):
    dataset = SpeechDataset(lmdb_path=lmdb_file, lmdb_key = keyfile, world_size = num_part, world_id = part_index, bunchsize = bunchsize, seed = shuffle_seed, Tmax=Tmax)
    # sampler = DistributedSampler(dataset=dataset)
    sampler = RandomSampler(dataset)
    train_data = PrefetchDataLoader(dataset, 1,  num_workers = num_workers, sampler=sampler, worker_init_fn=worker_init_fn,drop_last=True, pin_memory=True)
    # sampler.set_epoch(epoch)
    return train_data
